﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relatorios_Teste
{
    internal class Boletos
    {
        public int Id_Guia { get; set; }
        public string CodigoBarra { get; set; }
        public string LinhaDigitavel { get; set; }
        public string NossoNumero { get; set; }
        public string NumDocumento { get; set; }
        public decimal Valor_Guia { get; set; }
        public string Observacao { get; set; }
        public string Login { get; set; }
        public int PpID { get; set; }
        public DateTime Data_Vencimento { get; set; }
        public DateTime Data_Pagamento { get; set; }
        public decimal Valor_Pago { get; set; }
        public string Banco_Pagamento { get; set; }
        public DateTime Data_Baixa { get; set; }
        public DateTime Data_Processamento { get; set; }

        public static DataTable ObterBoleto()
        {
            var dt = new DataTable();

            dt.Columns.Add("Id_Guia", typeof(int));
            dt.Columns.Add("CodigoBarra", typeof(string));
            dt.Columns.Add("Observacao", typeof(string));

            dt.Rows.Add(27, "12345678989999999", $"Tipo de Preço Público:Poda de Arvore\r\n Com valor de : 1234");

            return dt;
        }
    }
}
