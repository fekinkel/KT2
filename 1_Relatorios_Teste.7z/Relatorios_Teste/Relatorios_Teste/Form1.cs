namespace Relatorios_Teste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TipoRelatorio("rptMegaSena");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TipoRelatorio("BoletoPP");
        }

        private void TipoRelatorio(string Tipo) 
        {
            using (var frm = new Visualizador(Tipo))
            {

                frm.ShowDialog();
            }
        }
    }
}
