﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relatorios_Teste
{
    public class Megas
    {
        public int Id { get; set; }
        public string? Titulo { get; set; }
        public string? Serie {  get; set; }
        public int Ano {  get; set; } 


        public static DataTable ObterMega() 
        {
            var dt = new DataTable();   

            dt.Columns.Add("Id", typeof(int));  
            dt.Columns.Add("Titulo", typeof(string));
            dt.Columns.Add("Serie", typeof (string));
            dt.Columns.Add("Ano", typeof(int));

            dt.Rows.Add(1, "50 tons de cinza", "Correto", 2024);
            dt.Rows.Add(2, "Black Mirror");

            return dt;

        }
    }
}
