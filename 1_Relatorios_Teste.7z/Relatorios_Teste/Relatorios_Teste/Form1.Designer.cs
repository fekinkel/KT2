﻿namespace Relatorios_Teste
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMegaSena = new Button();
            btnBoleto = new Button();
            SuspendLayout();
            // 
            // btnMegaSena
            // 
            btnMegaSena.Location = new Point(155, 74);
            btnMegaSena.Name = "btnMegaSena";
            btnMegaSena.Size = new Size(75, 23);
            btnMegaSena.TabIndex = 0;
            btnMegaSena.Text = "MegaSena";
            btnMegaSena.UseVisualStyleBackColor = true;
            btnMegaSena.Click += button1_Click;
            // 
            // btnBoleto
            // 
            btnBoleto.Location = new Point(326, 129);
            btnBoleto.Name = "btnBoleto";
            btnBoleto.Size = new Size(75, 23);
            btnBoleto.TabIndex = 1;
            btnBoleto.Text = "BoletoPP";
            btnBoleto.UseVisualStyleBackColor = true;
            btnBoleto.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(484, 259);
            Controls.Add(btnBoleto);
            Controls.Add(btnMegaSena);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnMegaSena;
        private Button btnBoleto;
    }
}
