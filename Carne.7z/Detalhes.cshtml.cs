using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebBoletoPP.Pages.Carne
{
    public class DetalhesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
