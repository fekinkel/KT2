﻿using ExportarRdlcToPdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


namespace ExportarPdf
{
    [Guid("060531de-426a-40d0-addd-c8147e5aa8b0")]
    [ComVisible(true)]
        public class Class
    {
        
        public string ExpRdlcToPDF(string NomeRdlc, string DsRdlc, string DadosRdlc)
        {
            //NomeRdlc - Nome do relatório
            //DcRdlc - Nome do DataSource do Relatório
            //DadosRdlc - Dados para o Relatório
            string Error = "";
                if (String.IsNullOrEmpty(NomeRdlc))
                {
                    Error = "Nome não é válido!";
                }
                else
                {
                    string vlPath = Directory.GetCurrentDirectory();

                    string vlFile = vlPath + "\\rpt\\" + NomeRdlc;

                    if (File.Exists(vlFile))
                    {
                        LerRdlc ler = new LerRdlc();

                        Error = ler.SaidaPdf(vlFile, DsRdlc, DadosRdlc);
                    }
                    else
                    {
                        Error = $"Arquivo não existe: {vlFile}";
                    }
                    //Console.WriteLine(File.Exists(vlFile) ? "File exists." : "File does not exist.");
                }
            
            return (Error);
        }
    }
}
