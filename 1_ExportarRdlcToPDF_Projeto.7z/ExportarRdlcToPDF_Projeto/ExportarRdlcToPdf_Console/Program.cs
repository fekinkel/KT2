﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ExportarRdlcToPdf
{
    class Program
    {
        static void Main(string[] args)
        {
            //arg[0] = NomeRdlc - Nome do relatório
            //arg[1] = DcRdlc - Nome do DataSource do Relatório
            //arg[2] = DadosRdlc - Dados para o Relatório
            string Error = "";
            if (args.Length == 0 || args.Length < 3)
            {
                Error = "Sem parametros ou Parametro faltando";
            }
            else
            {
                var NomeRdlc = args[0];
                var DcRdlc = args[1];
                var DadosRdlc = args[2];
                if (String.IsNullOrEmpty(NomeRdlc))
                {
                    Error = "Nome não é válido!";
                }
                else
                {
                    string vlPath = Directory.GetCurrentDirectory();
                    
                    string vlFile = vlPath + "\\rpt\\"+ NomeRdlc;

                    if (File.Exists(vlFile))
                    {
                        LerRdlc ler = new LerRdlc();

                        Error = ler.SaidaPdf(vlFile, DcRdlc, DadosRdlc);
                    }
                    else
                    {
                        Error = "Arquivo não existe";
                    }
                    //Console.WriteLine(File.Exists(vlFile) ? "File exists." : "File does not exist.");
                }
            }
            Console.WriteLine(Error);

        }
    }
}
