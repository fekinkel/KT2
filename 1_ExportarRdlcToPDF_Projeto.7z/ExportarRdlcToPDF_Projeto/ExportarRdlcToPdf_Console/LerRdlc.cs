﻿using Microsoft.Build.Tasks;
using Microsoft.Reporting.WebForms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportarRdlcToPdf
{
    class LerRdlc
    {
        public string SaidaPdf(string vpFile, string vpDs, string vpDados)
        {            
            string retorno = "";
            string deviceInfo = "";
            string[] streamIds;
            Microsoft.Reporting.WebForms.Warning[] warnings;
            string mineTypes = string.Empty;
            string encoding = string.Empty;
            string extension = string.Empty;

            ReportViewer viewer = new ReportViewer();
            viewer.ProcessingMode = ProcessingMode.Local;
            viewer.LocalReport.ReportPath = vpFile;// "rptBoletoPP.rdlc";
            //viewer.LocalReport.DataSources.Add(new ReportDataSource("dsBoletoPP", GetBoletoPPData()));
            try
            {
                vpDados = vpDados.Replace("'", "\"");

                JArray srcArray = JArray.Parse(vpDados);

                var trgArray = new JArray();

                foreach (JObject row in srcArray.Children<JObject>())
                {
                    var cleanRow = new JObject();
                    foreach (JProperty column in row.Properties())
                    {
                        // Only include JValue types
                        if (column.Value is JValue)
                        {
                            cleanRow.Add(column.Name, column.Value);
                        }
                    }

                    trgArray.Add(cleanRow);
                }
                
                

                DataTable listaPP = JsonConvert.DeserializeObject<DataTable>(trgArray.ToString());

                viewer.LocalReport.DataSources.Add(new ReportDataSource(vpDs, listaPP));
                
                var bytes = viewer.LocalReport.Render("PDF", deviceInfo, out mineTypes, out encoding,
                                                        out extension, out streamIds, out warnings);

                retorno = Convert.ToBase64String(bytes);
                
                //retorno = Encoding.UTF8.GetString(bytes); //Retorna em UTF8

                //string filename = $@"C:\Temp\BoletoPPdata_{DateTime.Now.Year.ToString()}_{DateTime.Now.Month.ToString()}_{DateTime.Now.Day.ToString()}_{DateTime.Now.Hour.ToString()}_{DateTime.Now.Minute.ToString()}_.pdf";
                //File.WriteAllBytes(filename, bytes);
                //System.Diagnostics.Process.Start(filename);

                //retorno = $"Até aqui {filename}";




            }
            catch
            {
                //retorno = "Erro";
                //retorno = JsonConvert.SerializeObject(GetBoletoPPData());
                retorno = $"Erro ao converter PDF ";
            }
            
            //viewer.LocalReport.Refresh();




            return retorno;
        }
        private List<DadosBoletoPP> GetBoletoPPData()
        {
            return new List<DadosBoletoPP>
            {
                new DadosBoletoPP{Nome="Fernando",Sobrenome="Kinkel Serejo", Endereço="Jacinto Pagliato", Valor=1254.32},
            };
        }
        public class DadosBoletoPP
        {
            public string Nome { get; set; }
            public string Sobrenome { get; set; }
            public string Endereço { get; set; }
            public double Valor { get; set; }
        }
    }
}
